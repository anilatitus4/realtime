import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
import json
from datetime import datetime

class ParseMessageDoFn(beam.DoFn):
    def process(self, element):
        # Pub/Sub messages arrive as bytes, decode and parse JSON
        record = json.loads(element.decode('utf-8'))
        
        # Optional: add or transform fields
        record['timestamp'] = datetime.utcnow().isoformat()
        
        # Map fields for BigQuery insert
        yield {
            'timestamp': record['timestamp'],
            'message': record.get('message', '')
        }

def run():
    options = PipelineOptions()
    options.view_as(StandardOptions).streaming = True

    with beam.Pipeline(options=options) as p:
        (
            p
            | 'Read from PubSub' >> beam.io.ReadFromPubSub(subscription='projects/realtime-data-pipeline-123/subscriptions/realtime-stream-sub')
            | 'Parse JSON' >> beam.ParDo(ParseMessageDoFn())
            | 'Write to BigQuery' >> beam.io.WriteToBigQuery(
                'realtime-data-pipeline-123:realtime_dataset.streaming_output',
                schema='timestamp:TIMESTAMP,message:STRING',
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                create_disposition=beam.io.BigQueryDisposition.CREATE_NEVER
              )
        )

if __name__ == '__main__':
    run()
